function copyText(text) {
  navigator.clipboard.writeText(text);
  alert("Copied: " + text);
}
function shareText(text) {
  if (navigator.share) {
    navigator.share({ text });
  } else {
    alert("Sharing not supported");
  }
}